﻿using System;
using Seasar.Dao.Attrs; //S2Dao.NETの属性を使用
using S2DaoSample.Entity;

namespace S2DaoSample.Dao {
    /// <summary>
    /// Bookテーブルにアクセスする為のDao
    /// </summary>
    [Bean(typeof(Book))] //対応するEntityを指定
    public interface IBookDao{

        //全件取得
        Book[] GetAllBook();
        //INSERT
        int Insert(Book book);
        //UPDATE
        int Update(Book book);
        //DELETE
        int Delete(Book book);

        //価格平均をSELECT(SQL全文を記述)
        [Sql("SELECT AVG(price) FROM book")]
        int GetAvgPrice();

        //タイトルによるLike検索(WHERE句を付加)
        [Query("title LIKE /*book.Title*/")]
        Book[] GetByTitle(Book book);

        //外部ファイル(IBookDao_GetBetweenPrice.sql)のSQLを実行
        Book[] GetBetweenPrice(int low,int high);
    }
}
