﻿using System;
using Seasar.Dao.Attrs; //S2Dao.NETの属性を使用

namespace S2DaoSample.Entity {

    /// <summary>
    /// Bookエンティティ(書籍データを格納する入れ物)
    /// </summary>
    public class Book {

        private int _id;
        private String _title;
        private int _price;	
        private DateTime _editdate;

        //ID
        public int Id {
            get { return _id; }
            set { _id = value; }
        }

        //タイトル
        public string Title {
            get { return _title; }
            set { _title = value; }
        }

        //価格
        public int Price {
            get { return _price; }
            set { _price = value; }
        }

        //更新日
        [Column("EDIT_DATE")] //プロパティとカラム名が異なるときに指定
        public DateTime Editdate {
            get { return _editdate; }
            set { _editdate = value; }
        }

    }
}
