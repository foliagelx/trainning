﻿using System;
using System.Collections.Generic;
using Seasar.Framework.Container;
using Seasar.Framework.Container.Factory;
using log4net;
using System.IO;
using log4net.Util;
using System.Reflection;
using log4net.Config;

using S2DaoSample.Dao;
using S2DaoSample.Entity;
using Seasar.Framework.Log;

namespace S2DaoSample
{
    class Program
    {
        //ロガーを取得
        private static readonly log4net.ILog logger = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        
        //コンソールアプリケーションのエントリポイント
        static void Main(string[] args) {
            //log4netの初期化
            InitApplication();

            //アプリケーション構成ファイルに定義されたDiconファイルのパスを取得
            string diconPath = SingletonS2ContainerFactory.ConfigPath;
            //S2Containerを初期化
            IS2Container container = S2ContainerFactory.Create(diconPath);
            
            //直接指定する例
            //IS2Container container = S2ContainerFactory.Create("S2DaoSample.Dicon.Dao.dicon");

            //どこでもS2Containerを利用できるようにS2Containerをセット
            //SingletonS2ContainerFactory.Container = container;
            
            //BookDaoを取得
            logger.Info("---▼IBookDaoを取得---");
            IBookDao bookDao = (IBookDao)container.GetComponent(typeof(IBookDao));
            

            //INSERT（追加）
            logger.Info("---▼INSERT---");
            Book book = new Book();
            book.Id = 100;
            book.Title = "初めてのS2Dao.NET";
            book.Price = 2000;
            book.Editdate = DateTime.Today;
            int retCnt = bookDao.Insert(book);
            logger.Info(retCnt + "件挿入しました");

            logger.Info("---▼UPDATE---");
            //UPDATE (更新)
            book.Title = "応用S2Dao.NET";
            book.Price = 3000;
            retCnt = bookDao.Update(book);
            logger.Info(retCnt + "件更新しました");

            //SELECT (書籍を複数件 選択)
            logger.Info("---▼SELECT(書籍を複数件 選択)---");
            Array books = bookDao.GetAllBook();
            foreach (Book bk in books) {
                logger.Info(bk.Id + "\t" + bk.Title + "(" + bk.Price + "円)");
            }

            //SELECT (平均価格の取得)
            logger.Info("---▼SELECT(平均価格の取得)---");
            logger.Info("平均価格:" + bookDao.GetAvgPrice() + "円");

            //SELECT (複数件 LIKE条件選択)
            logger.Info("---▼SELECT(複数件 LIKE条件選択)---");
            book.Title = "%応用%";
            books = bookDao.GetByTitle(book);
            foreach (Book bk in books) {
                logger.Info(bk.Id + "\t" + bk.Title + "(" + bk.Price + "円)");
            }

            //SELECT (複数件 BETWEEN条件選択)
            logger.Info("---▼SELECT(複数件 BETWEEN条件選択)---");
            books = bookDao.GetBetweenPrice(2000,3000);
            foreach (Book bk in books) {
                logger.Info(bk.Id + "\t" + bk.Title + "(" + bk.Price + "円)");
            }

            logger.Info("---▼DELETE---");
            //DELETE (削除)
            book.Id = 100;
            retCnt = bookDao.Delete(book);
            logger.Info(retCnt + "件削除しました");

            //結果を表示して停止
            logger.Info("完了です");
            Console.ReadLine(); 

        }

        //初期化を行なうメソッド
        private static void InitApplication()
        {
            //アプリケーション構成ファイル(<アプリケーション名>.exe.config)の取得
            FileInfo info = new FileInfo(SystemInfo.AssemblyShortName(
               Assembly.GetExecutingAssembly()) + ".exe.config");
            //ログ出力ライブラリ「log4net」の初期化
            XmlConfigurator.Configure(LogManager.GetRepository(), info);
        }
    }
}